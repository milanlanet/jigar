package com.example.stickerviewdemo.dialog;

import android.os.Bundle;
import android.support.annotation.ColorInt;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import com.example.stickerviewdemo.R;
import com.rtugeek.android.colorseekbar.ColorSeekBar;

public class StickerTintDialog extends DialogFragment implements View.OnClickListener {
    private View rootView;
    private ImageView iv_sticker;
    int selectedSticker;
    private OnStickerSelect onStickerSelect;
    private Button btnDone;
    private Button btnCancel;
    int tintColor = 0;
    private ColorSeekBar colorSeekBar;

    public interface OnStickerSelect {
        void selectedSticker(int stickerId, int tintColor);
    }

    public StickerTintDialog(int selectedSticker, OnStickerSelect onStickerSelect) {
        this.selectedSticker = selectedSticker;
        this.onStickerSelect = onStickerSelect;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_sample_dialog, container, false);
        getDialog().setTitle("Choose Sticker");
        colorSeekBar = (ColorSeekBar) rootView.findViewById(R.id.colorSlider);
        iv_sticker = (ImageView) rootView.findViewById(R.id.iv_sticker);
        iv_sticker.setImageResource(selectedSticker);
        btnDone = (Button) rootView.findViewById(R.id.done);
        btnDone.setOnClickListener(this);

        btnCancel = (Button) rootView.findViewById(R.id.cancel);
        btnCancel.setOnClickListener(this);

        colorSeekBar.setOnColorChangeListener(new ColorSeekBar.OnColorChangeListener() {
            @Override
            public void onColorChangeListener(int colorBarValue, int alphaBarValue, int color) {
                tintColor = color;
                iv_sticker.setColorFilter(color, android.graphics.PorterDuff.Mode.MULTIPLY);
            }
        });
        return rootView;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.done:
                onStickerSelect.selectedSticker(selectedSticker, tintColor);
                dismiss();
                break;
            case R.id.cancel:
                dismiss();
                break;
        }
    }
}