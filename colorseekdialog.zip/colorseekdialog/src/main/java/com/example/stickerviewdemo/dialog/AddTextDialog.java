package com.example.stickerviewdemo.dialog;

import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.stickerviewdemo.R;
import com.example.stickerviewdemo.Utility;
import com.rtugeek.android.colorseekbar.ColorSeekBar;


/**
 * Created by lcom56 on 4/11/15.
 */
public class AddTextDialog extends Dialog implements View.OnClickListener {
    public Context context;
    public Button positive;
    public Button negative;
    Spinner font, texture;
    EditText edit_new_text;
    String _text;
    AddText _interface;
    String selected_font = "NexaLight";
    int _color;
    ColorSeekBar colorSeekBar;
    String[] fonatarr = {"Select font", "Normal", "Helvetica", "NexaLight", "Museo", "Sans serif", "Monospace", "Serif", "FFF_Tusj", "black_jack", "Capture_it", "GoodDog", "Sofia-Regular"};
    String[] texturearry = {"NONE", "CHEETAH", "GREENCUP", "CONGRUENTOUTLINE", "CONGRUENTPENTAGON", "FLOWER1", "FLOWER2", "PATTERN1", "PATTERN2", "PATTERN3", "PATTERN4", "PATTERN5", "PATTERN6"};
    String selected_texture;

    public interface AddText {
        void setTextview(String _text, int _color, String font, String texture);
    }

    public AddTextDialog(final Context context, AddText _interface) {
        super(context);
        this.context = context;
        this._interface = _interface;
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.setCanceledOnTouchOutside(false);
        this.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        this.setContentView(R.layout.newtextdialog);
        texture = (Spinner) findViewById(R.id.texture);
        positive = (Button) findViewById(R.id.done_text);
        positive.setOnClickListener(this);
        negative = (Button) findViewById(R.id.cancle_text);
        negative.setOnClickListener(this);
        edit_new_text = (EditText) findViewById(R.id.edit_new_text_dialog);
        colorSeekBar = (ColorSeekBar) findViewById(R.id.colorSlider);
        _color = colorSeekBar.getColor();
        edit_new_text.setTextColor(_color);
        colorSeekBar.setOnColorChangeListener(new ColorSeekBar.OnColorChangeListener() {
            @Override
            public void onColorChangeListener(int colorBarValue, int alphaBarValue, int color) {
                edit_new_text.setTextColor(color);
                _color = color;
            }
        });
        font = (Spinner) findViewById(R.id.font);
        SpinnerAdapter spinnerAdapter = new SpinnerAdapter(context, R.layout.dropdown_item, fonatarr, "Sample Text");
        font.setAdapter(spinnerAdapter);
        selected_texture = "";
        texture.setAdapter(new SpinnerTextureAdapter(context, R.layout.dropdown_item, texturearry, "Texture"));

        font.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View v, int position, long id) {
                if (!fonatarr[position].equalsIgnoreCase("Select font"))
                    selected_font = fonatarr[position];
                if (selected_font.equalsIgnoreCase("NexaLight")) {
                    edit_new_text.setTypeface(Utility.GetNexaLight(getContext()));
                }
                if (selected_font.equalsIgnoreCase("Helvetica")) {
                    edit_new_text.setTypeface(Utility.GetHelvetica(getContext()));
                }
                if (selected_font.equalsIgnoreCase("Museo")) {
                    edit_new_text.setTypeface(Utility.Getmuseo(getContext()));
                }
                if (selected_font.equalsIgnoreCase("Sans serif")) {
                    edit_new_text.setTypeface(Typeface.SANS_SERIF);
                }
                if (selected_font.equalsIgnoreCase("Monospace")) {
                    edit_new_text.setTypeface(Typeface.MONOSPACE);
                }
                if (selected_font.equalsIgnoreCase("Serif")) {
                    edit_new_text.setTypeface(Typeface.SERIF);
                }
                if (selected_font.equalsIgnoreCase("Normal")) {
                    edit_new_text.setTypeface(Typeface.DEFAULT);
                }
                if (selected_font.equalsIgnoreCase("Normal")) {
                    edit_new_text.setTypeface(Typeface.DEFAULT);
                }
                if (selected_font.equalsIgnoreCase("FFF_Tusj")) {
                    edit_new_text.setTypeface(Utility.GetFFF_Tusj(getContext()));
                }
                if (selected_font.equalsIgnoreCase("black_jack")) {
                    edit_new_text.setTypeface(Utility.Getblack_jack(getContext()));
                }
                if (selected_font.equalsIgnoreCase("Capture_it")) {
                    edit_new_text.setTypeface(Utility.GetCapture_it(getContext()));
                }

                if (selected_font.equalsIgnoreCase("GoodDog")) {
                    edit_new_text.setTypeface(Utility.GetGoodDog(getContext()));
                }

                if (selected_font.equalsIgnoreCase("Sofia-Regular")) {
                    edit_new_text.setTypeface(Utility.GetSofiaRegular(getContext()));
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });

        texture.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View v, int position, long id) {
                if (!texturearry[position].equalsIgnoreCase("Texture"))
                    selected_texture = texturearry[position];


            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });

    }


    private boolean isValid() {
        if (edit_new_text.getText().toString() != null && edit_new_text.getText().toString().trim().length() > 0) {
            return true;
        }
        return false;
    }

    @Override
    public void onClick(View v) {
        if (v == positive) {
            if (isValid()) {
                String text = edit_new_text.getText().toString();
                dismiss();
                _interface.setTextview(text, _color, selected_font, selected_texture);
                //onBackPressed();
            } else {
                edit_new_text.setError("Please enter text.");
            }
        }
        if (v == negative) {
            dismiss();
        }

    }

    public class SpinnerAdapter extends ArrayAdapter<String> {
        String text;
        String[] fontArr;

        public SpinnerAdapter(Context context, int textViewResourceId, String[] objects, String text) {
            super(context, textViewResourceId, objects);
            this.text = text;
            this.fontArr = objects;
        }

        @Override
        public View getDropDownView(int position, View convertView, ViewGroup parent) {
            return getCustomView(position, convertView, parent);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            return getCustomView(position, convertView, parent);
        }

        public View getCustomView(int position, View convertView, ViewGroup parent) {

            LayoutInflater inflater = getLayoutInflater();
            View row = inflater.inflate(R.layout.dropdown_item, parent, false);
            TextView label = (TextView) row.findViewById(R.id.ab_drop_menu_item_title);
            label.setText(fontArr[position]);
            if (fontArr[position].equalsIgnoreCase("NexaLight")) {
                label.setTypeface(Utility.GetNexaLight(getContext()));
            }
            if (fontArr[position].equalsIgnoreCase("Helvetica")) {
                label.setTypeface(Utility.GetHelvetica(getContext()));
            }
            if (fontArr[position].equalsIgnoreCase("Museo")) {
                label.setTypeface(Utility.Getmuseo(getContext()));
            }
            if (fontArr[position].equalsIgnoreCase("Sans serif")) {
                label.setTypeface(Typeface.SANS_SERIF);
            }
            if (fontArr[position].equalsIgnoreCase("Monospace")) {
                label.setTypeface(Typeface.MONOSPACE);
            }
            if (fontArr[position].equalsIgnoreCase("Serif")) {
                label.setTypeface(Typeface.SERIF);
            }
            if (fontArr[position].equalsIgnoreCase("Normal")) {
                label.setTypeface(Typeface.DEFAULT);
            }
            if (fontArr[position].equalsIgnoreCase("Normal")) {
                label.setTypeface(Typeface.DEFAULT);
            }
            if (fontArr[position].equalsIgnoreCase("FFF_Tusj")) {
                label.setTypeface(Utility.GetFFF_Tusj(getContext()));
            }
            if (fontArr[position].equalsIgnoreCase("black_jack")) {
                label.setTypeface(Utility.Getblack_jack(getContext()));
            }
            if (fontArr[position].equalsIgnoreCase("Capture_it")) {
                label.setTypeface(Utility.GetCapture_it(getContext()));
            }

            if (fontArr[position].equalsIgnoreCase("GoodDog")) {
                label.setTypeface(Utility.GetGoodDog(getContext()));
            }

            if (fontArr[position].equalsIgnoreCase("Sofia-Regular")) {
                label.setTypeface(Utility.GetSofiaRegular(getContext()));
            }
//            Bitmap bitmap = BitmapFactory.decodeResource(this.getContext().getResources(), R.drawable.cheetah_tile);
//            Shader shader = new BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
//            label.getPaint().setShader(shader);
            return row;
        }
    }


    public class SpinnerTextureAdapter extends ArrayAdapter<String> {
        String text;
        String[] textureArr;


        public SpinnerTextureAdapter(Context context, int textViewResourceId, String[] objects, String text) {
            super(context, textViewResourceId, objects);
            this.text = text;
            this.textureArr = objects;
        }

        @Override
        public View getDropDownView(int position, View convertView, ViewGroup parent) {
            return getCustomView(position, convertView, parent);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            return getCustomView(position, convertView, parent);
        }

        public View getCustomView(int position, View convertView, ViewGroup parent) {

            LayoutInflater inflater = getLayoutInflater();
            View row = inflater.inflate(R.layout.dropdown_item, parent, false);
            TextView label = (TextView) row.findViewById(R.id.ab_drop_menu_item_title);
            label.setText(textureArr[position]);
            if (textureArr[position].equalsIgnoreCase("CHEETAH")) {
                setTextureArr(this.getContext(), label, R.drawable.cheetah_tile);
            }
            if (textureArr[position].equalsIgnoreCase("GREENCUP")) {
                setTextureArr(this.getContext(), label, R.drawable.green_cup);
            }
            if (textureArr[position].equalsIgnoreCase("CONGRUENTOUTLINE")) {
                setTextureArr(this.getContext(), label, R.drawable.congruent_outline);
            }

            if (textureArr[position].equalsIgnoreCase("CONGRUENTPENTAGON")) {
                setTextureArr(this.getContext(), label, R.drawable.congruent_pentagon);
            }
            if (textureArr[position].equalsIgnoreCase("FLOWER1")) {
                setTextureArr(this.getContext(), label, R.drawable.flower_1);
            }
            if (textureArr[position].equalsIgnoreCase("FLOWER2")) {
                setTextureArr(this.getContext(), label, R.drawable.flower_2);
            }
            if (textureArr[position].equalsIgnoreCase("PATTERN1")) {
                setTextureArr(this.getContext(), label, R.drawable.pattern1);
            }
            if (textureArr[position].equalsIgnoreCase("PATTERN2")) {
                setTextureArr(this.getContext(), label, R.drawable.pattern2);
            }
            if (textureArr[position].equalsIgnoreCase("PATTERN3")) {
                setTextureArr(this.getContext(), label, R.drawable.pattern3);
            }
            if (textureArr[position].equalsIgnoreCase("PATTERN4")) {
                setTextureArr(this.getContext(), label, R.drawable.pattern4);
            }
            if (textureArr[position].equalsIgnoreCase("PATTERN5")) {
                setTextureArr(this.getContext(), label, R.drawable.pattern5);
            }
            if (textureArr[position].equalsIgnoreCase("PATTERN6")) {
                setTextureArr(this.getContext(), label, R.drawable.pattern6);
            }


            return row;
        }


    }

    public static void setTextureArr(Context context, TextView textView, int drawable) {
        Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), drawable);
        Shader shader = new BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
        textView.getPaint().setShader(shader);
    }
}
