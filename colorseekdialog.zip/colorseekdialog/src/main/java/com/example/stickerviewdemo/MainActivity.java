package com.example.stickerviewdemo;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.stickerviewdemo.MyTouch.MultiTouchListener;
import com.example.stickerviewdemo.dialog.AddTextDialog;
import com.example.stickerviewdemo.dialog.StickerTintDialog;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button btn_dialog;
    private TextView tv;
    private ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = (TextView) findViewById(R.id.tv);

        btn_dialog = (Button) findViewById(R.id.btn_dialog);
        btn_dialog.setOnClickListener(this);
        img = (ImageView) findViewById(R.id.img);
        img.setOnTouchListener(new MultiTouchListener(true, false, false));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_dialog:
               /* AddTextDialog addTextDialog = new AddTextDialog(this, new AddTextDialog.AddText() {
                    @Override
                    public void setTextview(String _text, int _color, String selected_font, String selected_texture) {
                        tv.setText(_text);
                        tv.setTextColor(_color);
                        if (selected_font.equalsIgnoreCase("NexaLight")) {
                            tv.setTypeface(Utility.GetNexaLight(getApplicationContext()));
                        }
                        if (selected_font.equalsIgnoreCase("Helvetica")) {
                            tv.setTypeface(Utility.GetHelvetica(getApplicationContext()));
                        }
                        if (selected_font.equalsIgnoreCase("Museo")) {
                            tv.setTypeface(Utility.Getmuseo(getApplicationContext()));
                        }
                        if (selected_font.equalsIgnoreCase("Sans serif")) {
                            tv.setTypeface(Typeface.SANS_SERIF);
                        }
                        if (selected_font.equalsIgnoreCase("Monospace")) {
                            tv.setTypeface(Typeface.MONOSPACE);
                        }
                        if (selected_font.equalsIgnoreCase("Serif")) {
                            tv.setTypeface(Typeface.SERIF);
                        }
                        if (selected_font.equalsIgnoreCase("Normal")) {
                            tv.setTypeface(Typeface.DEFAULT);
                        }
                        if (selected_font.equalsIgnoreCase("Normal")) {
                            tv.setTypeface(Typeface.DEFAULT);
                        }
                        if (selected_font.equalsIgnoreCase("FFF_Tusj")) {
                            tv.setTypeface(Utility.GetFFF_Tusj(getApplicationContext()));
                        }
                        if (selected_font.equalsIgnoreCase("black_jack")) {
                            tv.setTypeface(Utility.Getblack_jack(getApplicationContext()));
                        }
                        if (selected_font.equalsIgnoreCase("Capture_it")) {
                            tv.setTypeface(Utility.GetCapture_it(getApplicationContext()));
                        }

                        if (selected_font.equalsIgnoreCase("GoodDog")) {
                            tv.setTypeface(Utility.GetGoodDog(getApplicationContext()));
                        }

                        if (selected_font.equalsIgnoreCase("Sofia-Regular")) {
                            tv.setTypeface(Utility.GetSofiaRegular(getApplicationContext()));
                        }
                        if (selected_texture.equalsIgnoreCase("CHEETAH")) {
                            AddTextDialog.setTextureArr(getApplicationContext(), tv, R.drawable.cheetah_tile);
                        }
                        if (selected_texture.equalsIgnoreCase("GREENCUP")) {
                            AddTextDialog.setTextureArr(getApplicationContext(), tv, R.drawable.green_cup);
                        }
                        if (selected_texture.equalsIgnoreCase("CONGRUENTOUTLINE")) {
                            AddTextDialog.setTextureArr(getApplicationContext(), tv, R.drawable.congruent_outline);
                        }
                        if (selected_texture.equalsIgnoreCase("NEWYEAR")) {
                            AddTextDialog.setTextureArr(getApplicationContext(), tv, R.drawable.new_year_background);
                        }
                        if (selected_texture.equalsIgnoreCase("TREEBARK")) {
                            AddTextDialog.setTextureArr(getApplicationContext(), tv, R.drawable.tree_bark);
                        }
                        if (selected_texture.equalsIgnoreCase("OLDMAP")) {
                            AddTextDialog.setTextureArr(getApplicationContext(), tv, R.drawable.old_map);
                        }

                        if (selected_texture.equalsIgnoreCase("CONGRUENTPENTAGON")) {
                            AddTextDialog.setTextureArr(getApplicationContext(), tv, R.drawable.congruent_pentagon);
                        }
                        if (selected_texture.equalsIgnoreCase("FLOWER1")) {
                            AddTextDialog.setTextureArr(getApplicationContext(), tv, R.drawable.flower_1);
                        }
                        if (selected_texture.equalsIgnoreCase("FLOWER2")) {
                            AddTextDialog.setTextureArr(getApplicationContext(), tv, R.drawable.flower_2);
                        }
                        if (selected_texture.equalsIgnoreCase("PATTERN1")) {
                            AddTextDialog.setTextureArr(getApplicationContext(), tv, R.drawable.pattern1);
                        }
                        if (selected_texture.equalsIgnoreCase("PATTERN2")) {
                            AddTextDialog.setTextureArr(getApplicationContext(), tv, R.drawable.pattern2);
                        }
                        if (selected_texture.equalsIgnoreCase("PATTERN3")) {
                            AddTextDialog.setTextureArr(getApplicationContext(), tv, R.drawable.pattern3);
                        }
                        if (selected_texture.equalsIgnoreCase("PATTERN4")) {
                            AddTextDialog.setTextureArr(getApplicationContext(), tv, R.drawable.pattern4);
                        }
                        if (selected_texture.equalsIgnoreCase("PATTERN5")) {
                            AddTextDialog.setTextureArr(getApplicationContext(), tv, R.drawable.pattern5);
                        }
                        if (selected_texture.equalsIgnoreCase("PATTERN6")) {
                            AddTextDialog.setTextureArr(getApplicationContext(), tv, R.drawable.pattern6);
                        }
                    }
                });
                addTextDialog.show();*/

                android.support.v4.app.FragmentManager fm = getSupportFragmentManager();
                StickerTintDialog dialogFragment = new StickerTintDialog(R.drawable.sticker1, new StickerTintDialog.OnStickerSelect() {
                    @Override
                    public void selectedSticker(int stickerId, int tintColor) {

                    }
                });
                dialogFragment.show(fm, "Sample Fragment");
                break;
        }
    }
}
