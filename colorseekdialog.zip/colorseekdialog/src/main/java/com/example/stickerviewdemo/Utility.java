package com.example.stickerviewdemo;

import android.content.Context;
import android.graphics.Typeface;


/**
 * Created by lcom28 on 4/8/15.
 */
public class Utility {


    public static Typeface Getmuseo(Context _context) {
        Typeface custom_font = Typeface.createFromAsset(_context.getAssets(), "font/museo_300_regular.ttf");
        return custom_font;
    }

    public static Typeface GetHelvetica(Context _context) {
        Typeface custom_font = Typeface.createFromAsset(_context.getAssets(), "font/Helvetica.ttf");
        return custom_font;
    }

    public static Typeface GetNexaLight(Context _context) {
        Typeface custom_font = Typeface.createFromAsset(_context.getAssets(), "font/nexalight.ttf");
        return custom_font;
    }
    public static Typeface GetFFF_Tusj(Context _context) {
        Typeface custom_font = Typeface.createFromAsset(_context.getAssets(), "font/FFF_Tusj.ttf");
        return custom_font;
    }
    public static Typeface Getblack_jack(Context _context) {
        Typeface custom_font = Typeface.createFromAsset(_context.getAssets(), "font/black_jack.ttf");
        return custom_font;
    }
    public static Typeface GetCapture_it(Context _context) {
        Typeface custom_font = Typeface.createFromAsset(_context.getAssets(), "font/Capture_it.ttf");
        return custom_font;
    }
    public static Typeface GetGoodDog(Context _context) {
        Typeface custom_font = Typeface.createFromAsset(_context.getAssets(), "font/GoodDog.otf");
        return custom_font;
    }
    public static Typeface GetSofiaRegular(Context _context) {
        Typeface custom_font = Typeface.createFromAsset(_context.getAssets(), "font/SofiaRegular.otf");
        return custom_font;
    }


}
